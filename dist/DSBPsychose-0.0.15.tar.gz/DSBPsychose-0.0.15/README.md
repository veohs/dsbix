Install requirements before you do anything!
'pip install -r requirements.txt"
Any issues contact me on Github